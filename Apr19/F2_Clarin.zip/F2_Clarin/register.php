<?php
	include 'connect.php';
?>

<html lang="en" dir="ltr">
	<head>
		<meta charset = "UTF-8">
		<title> Task Ease - Register</title>
		<link rel="stylesheet" href="css/registerCSS.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
		<script src="js/redirect-pages.js"></script>
		<script src="js/format-pages.js"></script>
		<meta name = "viewport" content = "width=device-width, initial-scale=1.0">
	</head>
   
	<body>
		<div class="page-header">
			<div class="header-home" onclick="redirectToIndex();">
				<div class="header-logo">
					<img src = "images/taskeaseLogo2.png" />
				</div>
						
				<div class="header-logo-name">
					<div class="name-upper-text">
						<span> TaskEase </span>
					</div>
						
					<div class="name-lower-text">
						<span> task managemen</span>t
					</div>
				</div>
			</div>
			
			<div class="header-identifier" onmouseover="changeContent()" onmouseout="resetContent()" onclick="redirectToLast();">
				<span> REGISTER </span>
			</div>
		</div>
		
		<div class="register-body">
			<div class="body-header"> Registration </div>
			
			<div class="body-content">
				<form action="#" method="post">
					<div class="user-details">
						<div class="input-box">
							<span class="details"> First Name </span>
							<input type="text" name = "firstname" placeholder="Enter your first name" required>
						</div>
						
						<div class="input-box">
							<span class="details">Last Name </span>
							<input type="text" name = "lastname" placeholder="Enter your last name" required>
						</div>
						
						<div class="input-box">
							<span class="details"> Username </span>
							<input type="text" name = "username" placeholder="Enter your username" required>
						</div>
						
						<div class="input-box">
							<span class="details"> Email </span>
							<input type="text" name = "emailadd" placeholder="Enter your email" required>
						</div>
						
						<div class="input-box">
							<span class="details"> Password </span>
							<input type="password" name = "password" placeholder="Enter your password" required>
						</div>
						
						<div class="input-box">
							<span class="details"> Confirm Password </span>
							<input type="password" name = "confirmpassword" placeholder="Confirm your password" required>
						</div>
					</div>
					
					<div class="register-button">
						<input type="submit" name="btnRegister" value="Register">
					</div>
				</form>
				
				<div class="login-link">
					<span> Already have an account? <a href="login.php"> Login now </a> </span>
				</div>
			</div>
		</div>

	<?php
		$register_success = "<script language='javascript'>
		let errorMessage = document.createElement('div');
		errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkgreen; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
		errorMessage.classList.add('error-message');
		errorMessage.textContent = 'Registered Successfully!';
		document.body.appendChild(errorMessage);

		setTimeout(() => {
			document.body.removeChild(errorMessage);
		}, 3000);
		</script>";
			
		$error_passwords = "<script language='javascript'>
		let errorMessage = document.createElement('div');
		errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkred; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
		errorMessage.classList.add('error-message');
		errorMessage.textContent = 'Passwords do not match. Please try again!';
		document.body.appendChild(errorMessage);

		setTimeout(() => {
			document.body.removeChild(errorMessage);
		}, 3000);
		</script>";
		
		$error_username = "<script language='javascript'>
		let errorMessage = document.createElement('div');
		errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkred; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
		errorMessage.classList.add('error-message');
		errorMessage.textContent = 'Username already exists. Please try again!';
		document.body.appendChild(errorMessage);

		setTimeout(() => {
			document.body.removeChild(errorMessage);
		}, 3000);
		</script>";
		
		$error_email = "<script language='javascript'>
		let errorMessage = document.createElement('div');
		errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkred; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
		errorMessage.classList.add('error-message');
		errorMessage.textContent = 'Email already exists. Please try again!';
		document.body.appendChild(errorMessage);

		setTimeout(() => {
			document.body.removeChild(errorMessage);
		}, 3000);
		</script>";
			
		if(isset($_POST['btnRegister'])){
			// Retrieve data from form and save the value to a variable
			
			// For tbluserprofile
			$firstname = $_POST['firstname'];
			$lastname = $_POST['lastname'];              
			
			// For tbluseraccount
			$username = $_POST['username'];
			$email = $_POST['emailadd'];
			$password = $_POST['password'];
			$confirmedpassword = $_POST['confirmpassword'];	
			
			// Check if the passwords match
			if($password != $confirmedpassword) {
				echo $error_passwords;
			} else {
				$hashed_password = password_hash($password, PASSWORD_DEFAULT);
			
				// Check tbluseraccount if username is already existing. Save info if false. Prompt msg if true.
				$sql_username = "SELECT * FROM tbluseraccount WHERE username='".$username."'";
				$sql_email = "SELECT * FROM tbluseraccount WHERE emailadd='".$email."'";
				
				$user_result = mysqli_query($connection, $sql_username);
				$email_result = mysqli_query($connection, $sql_email);
				
				$user_row = mysqli_num_rows($user_result);
				$email_row = mysqli_num_rows($email_result);
				
				if($user_row == 0 && $email_row == 0){
					// Save data to tbluserprofile    
					$sql1 = "INSERT INTO tbluserprofile (firstname, lastname) VALUES ('".$firstname."', '".$lastname."')";
					mysqli_query($connection, $sql1);
					
					// Save data to tbluseraccount    
					$sql = "INSERT INTO tbluseraccount (username, emailadd, password, confirmedpassword) VALUES ('".$username."', '".$email."', '".$hashed_password."', '".$confirmedpassword."')";
					mysqli_query($connection, $sql);
					
					echo $register_success;
				} else {
					if($user_row != 0) {
						echo $error_username;
					} else {
						echo $error_email;
					}
				}
			}
		}
	?>

	</body> 

</html>
