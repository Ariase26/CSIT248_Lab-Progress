<?php
    include 'connect.php';

    $sql = "SELECT * FROM tbluseraccount";
    $result = mysqli_query($connection, $sql);  

    if (isset($_POST['btnCreate'])) {
        $taskname = mysqli_real_escape_string($connection, $_POST['taskname']);
        $taskdescription = mysqli_real_escape_string($connection, $_POST['taskdescription']);
        $duedate = mysqli_real_escape_string($connection, $_POST['duedate']);

        $checkSql = "SELECT * FROM tblTask WHERE taskname = '$taskname'";
        $checkResult = mysqli_query($connection, $checkSql);
        $checkRow = mysqli_fetch_assoc($checkResult);

        if (mysqli_num_rows($checkResult) > 0) {
            echo "<script>alert('Task name already exists. Please choose a different name.');</script>";
        } else {
            $sql = "INSERT INTO tblTask(taskname, taskdescription, duedate) VALUES ('$taskname', '$taskdescription', '$duedate')";
            mysqli_query($connection, $sql);
        }
    }

    if (isset($_POST['btnDelete'])) {
        $taskid = mysqli_real_escape_string($connection, $_POST['taskID']);

        $sql = "DELETE FROM tblTask WHERE taskID = '$taskid'";
        mysqli_query($connection, $sql);
    }
?>


    <html>
        <head>
            <title> TaskEase - Report List </title>
            <link rel="stylesheet" href="css/profile.css">
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap">
            <script src="js/redirect-pages.js"></script>
            <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
        </head>

        <body>
            <div class="page-header">
                <div class="header-logo">
                    <img src = "images/taskeaseLogo2.png" />
                </div>

                <div class="header-logo-name">
                    <div class="name-upper-text">
                        <span> TaskEase </span>
                    </div>

                    <div class="name-lower-text">
                        <span> task management</span>
                    </div>
                </div>

                <div class="header-anchors" onclick="redirectToIndex();">
                    <span> HOME </span>
                </div>

                <div class="header-anchors" onclick="redirectToAboutus();">
                    <span> ABOUT US </span>
                </div>

                <div class="header-anchors" onclick="redirectToContactus();">
                    <span> CONTACT US </span>
                </div>
				
				<div class="header-anchors" onclick="redirectToDashboard()">
                    <span> DASHBOARD </span>
                </div>

                <div class="header-anchors" onclick="redirectToProfile()">
                    <span> REPORT PAGE </span>
                </div>
            </div>
			
			<h1 style="font-size: 60px;"> TASKEASE DATABASE LIST </h1>

            <div class="addtaskright">
				<div class="alltask-container">
                    <div class="headername">
                        <span> USER - ACCOUNT LIST </span>
                    </div>

                    <div class = "aboutus-body">
                        <div class="content-text">
                            <table class="createTable">
                                <tr>
                                    <td class="tableheader"> Account ID </td>
                                    <td class="tableheader"> User ID </td>
                                    <td class="tableheader"> Email Address </td>
                                    <td class="tableheader"> First Name </td>
                                    <td class="tableheader"> Last Name </td>
                                    <td class="tableheader"> Username </td>
                                </tr>
                                <?php
                                    $sql = "SELECT tbluseraccount.acctid, tbluserprofile.userid, tbluseraccount.emailadd, tbluserprofile.firstname, tbluserprofile.lastname, tbluseraccount.username FROM tbluseraccount JOIN tbluserprofile ON tbluseraccount.acctid = tbluserprofile.acctid";
                                    $result = mysqli_query($connection, $sql);
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        echo "<td>" . $row['acctid'] . "</td>";
                                        echo "<td>" . $row['userid'] . "</td>";
                                        echo "<td>" . $row['emailadd'] . "</td>";
                                        echo "<td>" . $row['firstname'] . "</td>";
                                        echo "<td>" . $row['lastname'] . "</td>";
                                        echo "<td>" . $row['username'] . "</td>";
                                        echo "</tr>";
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
					
					<br/>
					
					<div class="syntax">
						<div class="syntax-header"> SYNTAX </div>
						<p>
							SELECT tbluseraccount.acctid, tbluserprofile.userid, tbluseraccount.emailadd, tbluserprofile.firstname,<br/>
							&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp tbluserprofile.lastname, tbluseraccount.username <br/>
							FROM tbluseraccount <br/>
							JOIN tbluserprofile <br/>
							ON tbluseraccount.acctid = tbluserprofile.acctid <br/>
						</p>
					</div>
                </div>
				
				<div class="alltask-container">
                    <div class="headername">
                        <span> SECTION - TASK LIST </span>
                    </div>

                    <div class = "aboutus-body">
                        <div class="content-text">
                            <table class="createTable">
                                <tr>
                                    <td class="tableheader"> Status </td>
                                    <td class="tableheader"> Task Name </td>
                                    <td class="tableheader"> Task Description </td>
                                    <td class="tableheader"> Due Date </td>
                                </tr>
                                <?php
                                    $sql = "SELECT 'Deleted' as status, taskname, taskdescription, taskdate FROM tbltaskdeleted
                                            UNION ALL
                                            SELECT 'Ongoing' as status, taskname, taskdescription, taskdate FROM tblTask
                                            ORDER BY taskdate";
                                    $result = mysqli_query($connection, $sql);
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        echo "<td>". $row['status']. "</td>";
                                        echo "<td>". $row['taskname']. "</td>";
                                        echo "<td>". $row['taskdescription']. "</td>";
                                        echo "<td>". $row['taskdate']. "</td>";
                                        echo "</tr>";
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
					
					<br/>
					
					<div class="syntax">
						<div class="syntax-header"> SYNTAX </div>
						<p>
							SELECT 'Deleted' as status, taskname, taskdescription, taskdate FROM tbltaskdeleted UNION ALL <br/>
                            SELECT 'Ongoing' as status, taskname, taskdescription, taskdate FROM tblTask <br/>
                            ORDER BY taskdate"
						</p>
					</div>
                </div>
				
                <div class="alltask-container">
                    <div class="headername">
                        <span> TASK LIST </span>
                    </div>
                    <div class = "aboutus-body">
                        <div class="content-text">
                            <table class="createTable">
                                <tr>
                                    <td class="tableheader"> Task ID </td>
                                    <td class="tableheader"> Task Name </td>
                                    <td class="tableheader"> Task Description </td>
                                    <td class="tableheader"> Due Date </td>
                                </tr>
                                <?php
                                    $sql = "SELECT taskid, taskname, taskdescription, taskdate FROM tblTask";
                                    $result = mysqli_query($connection, $sql);
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        echo "<td>". $row['taskid']. "</td>";
                                        echo "<td>". $row['taskname']. "</td>";
                                        echo "<td>". $row['taskdescription']. "</td>";
                                        echo "<td>". $row['taskdate']. "</td>";
                                        echo "</tr>";
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
					
					<br/>
					
					<div class="syntax">
						<div class="syntax-header"> SYNTAX </div>
						<p>
							SELECT taskid, taskname, taskdescription, taskdate FROM tblTask
						</p>
					</div>
                </div>
            </div>
        </body>
    </html>