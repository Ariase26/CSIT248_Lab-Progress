function changeContent() {
	var element = document.querySelector('.header-identifier');
	element.classList.add('image');
	element.style.backgroundColor = '#E7C51D';
	element.style.width = '140px';
	element.style.border = '2px solid black';
	element.style.height = '40px'; 
  
	setTimeout(function() {
		resetContent(); 
	}, 100000);
}

function resetContent() {
	var element = document.querySelector('.header-identifier');
	element.classList.remove('image');
	element.style.backgroundColor = '#43161a'; 
	element.style.width = '190px';
	element.style.height = '45px';
	element.style.border = '0px';
}

window.onload = function() {
    function updateTime() {
        var date = new Date();
        var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var displayDate = monthNames[date.getMonth()] + " " + date.getDate() + ", " + date.getFullYear();
        var displayTime = date.toLocaleTimeString();
                
		document.getElementById('date').innerHTML = displayDate;
        document.getElementById('time').innerHTML = displayTime;
        setTimeout(updateTime, 1000);
    }
    
	updateTime();
};

