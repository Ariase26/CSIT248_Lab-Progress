<?php
	include 'connect.php';

	$taskName = $_GET['taskName'];
	$sql_select = "SELECT * FROM tbltask WHERE taskname='$taskName'";
	$result_select = mysqli_query($connection, $sql_select);
	$row = mysqli_fetch_assoc($result_select);

	$sql_insert = "INSERT INTO tbltaskdeleted (taskname, taskdescription, taskdate, deleted_date) 
				   VALUES ('".$row['taskname']."', '".$row['taskdescription']."', '".$row['taskdate']."', NOW())";
	$result_insert = mysqli_query($connection, $sql_insert);

	$sql_delete = "DELETE FROM tbltask WHERE taskname='$taskName'";
	$result_delete = mysqli_query($connection, $sql_delete);

	if ($result_delete) {
		echo "Task deleted successfully!";
	} else {
		echo "Error deleting task: " . mysqli_error($connection);
	}

	header('Location: dashboard.php');
	exit;
?>
