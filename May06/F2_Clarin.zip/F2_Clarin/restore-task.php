<?php
	include 'connect.php';

	$taskName = $_GET['taskName'];

	$sql_select = "SELECT * FROM tbltaskdeleted WHERE taskname = '$taskName'";
	$result_select = mysqli_query($connection, $sql_select);
	$row = mysqli_fetch_assoc($result_select);

	$sql_insert = "INSERT INTO tbltask (taskname, taskdescription, taskdate) 
				   VALUES ('".$row['taskname']."', '".$row['taskdescription']."', '".$row['taskdate']."')";
	$result_insert = mysqli_query($connection, $sql_insert);

	$sql_delete = "DELETE FROM tbltaskdeleted WHERE taskname = '$taskName'";
	$result_delete = mysqli_query($connection, $sql_delete);

	if ($result_insert && $result_delete) {
		echo "Task restored successfully!";
	} else {
		echo "Error restoring task: " . mysqli_error($connection);
	}

	header('Location: dashboard.php');
	exit;
?>
