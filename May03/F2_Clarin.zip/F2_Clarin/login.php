<?php
	include 'connect.php';
?>

<html lang="en" dir="ltr">
	<head>
		<meta charset="utf-8">
		<title> Task Ease - Log In</title>
		<link rel="stylesheet" href="css/loginCSS.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap">
		<script src="js/redirect-pages.js"></script>
		<script src="js/format-pages.js"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
   
	<body>
		<div class="page-header">
			<div class="header-home" onclick="redirectToIndex();">
				<div class="header-logo">
					<img src = "images/taskeaseLogo2.png" />
				</div>
						
				<div class="header-logo-name">
					<div class="name-upper-text">
						<span> TaskEase </span>
					</div>
						
					<div class="name-lower-text">
						<span> task managemen</span>t
					</div>
				</div>
			</div>
			
			<div class="header-identifier">
				<span> LOG IN</span>
			</div>
		</div>
		
		<div class="login-body">
			<div class="login-body-content">
				<div class="content-header">
					<span class="header-welcome"> Welcome</span> <br/>
					<span class="header-text"> stylish tasks, the new norm</span>
				</div>
				 
				<form action="#" method="post">
					<div class="field">
						<input type="text" name="emailadd" required>
						<label>Email Address</label>
					</div>
					
					<div class="field">
						<input type="password" name="password" required>
						<label>Password</label>
					</div>
					
					<div class="field">
						<input type="submit" value="Login" name="btnLogin">
					</div>
					
					<div class="signup-link">
						Not a member? <a href="register.php"> Signup now</a>
					</div>
				 </form>
			 </div>
			 
			 <div class="login-body-img">
				<img src="images/taskease-img2.jpg">
			 </div>
		</div>
		
		<?php
			$login_success = "<script language='javascript'>
			let errorMessage = document.createElement('div');
			errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkgreen; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
			errorMessage.classList.add('error-message');
			errorMessage.textContent = 'Login Successfully!';
			document.body.appendChild(errorMessage);
			
			setTimeout(() => {
				document.body.removeChild(errorMessage);
			}, 1000);
			
			setTimeout(() => {
				window.location.href = 'dashboard.php';
			}, 500);
			
			</script>";
			
			$login_failed = "<script language='javascript'>
			let errorMessage = document.createElement('div');
			errorMessage.style.cssText = 'display:flex; justify-content: center; align-content: center; position: absolute; top: 5vh; left: 50%; transform: translateX(-50%); background-color: darkred; color: white; padding: 20px; border-radius: 20px; width: auto; max-width: 500px; box-shadow: 0 0 13px 3px rgba(0, 0, 0, 0.5); ';
			errorMessage.classList.add('error-message');
			errorMessage.textContent = 'Login failed. Please try again!';
			document.body.appendChild(errorMessage);

			setTimeout(() => {
				document.body.removeChild(errorMessage);
			}, 3000);
			</script>";
			
			if(isset($_POST['btnLogin'])){
				$email = $_POST['emailadd'];
				$password = $_POST['password'];

				$sql2 = "Select * from tbluseraccount where emailadd='" . $email . "' AND confirmedpassword='" . $password . "'";
				$result = mysqli_query($connection, $sql2);
				$row = mysqli_num_rows($result);

				if($row == 0){
					echo $login_failed;
				}
				else{
					echo $login_success;
				}
			}
		?>
		
	</body>
	
</html>