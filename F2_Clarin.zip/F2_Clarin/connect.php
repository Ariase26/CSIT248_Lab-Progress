<?php 
	$connection = new mysqli('localhost', 'root','','dbclarinf2');
	
	if (!$connection){
		die (mysqli_error($mysqli));
	}
		
?>