function redirectToIndex() {
    window.location.href = 'index.php';
}

function redirectToLogin() {
    window.location.href = 'login.php';
}

function redirectToRegister() {
    window.location.href = 'register.php';
}

function redirectToAboutus() {
    window.location.href = 'aboutus.php';
}

function redirectToContactus() {
    window.location.href = 'contactus.php';
}

function redirectToProfile() {
    window.location.href = 'profile.php';
}

function redirectToLast() {
    window.history.back();
}