<?php
    include 'connect.php';
?>
 
<html>
    <head>
        <title> TaskEase - Dashboard </title>
        <link rel="stylesheet" href="css/dashboard1.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap">
        <script src="js/redirect-pages.js"></script>
        <script src="js/format-pages.js" defer></script>
        <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
    </head>
   
    <body>
        <div class="page-header">
            <div class="header-logo">
                <div>
                    <img src = "images/taskeaseLogo2.png" />
                </div>
               `
                <div class="button-name">
                    <span> TASKEAS</span>E
                </div>
            </div>
           
            <hr class="divider-line"/>
           
            <div class="button-logo" id="button-hover" onclick="redirectToIndex();">
                <div>
                    <img src = "images/home.png" />
                </div>
               
                <div class="button-name">
                    <span> HOM</span>E
                </div>
            </div>
           
            <div class="button-logo" id="button-hover" onclick="redirectToAboutus();">
                <div>
                    <img src = "images/about.png" />
                </div>
               
                <div class="button-name">
                    <span> ABOUT<br/>U</span>S
                </div>
            </div>
           
            <div class="button-logo" id="button-hover" onclick="redirectToContactus();">
                <div>
                    <img src = "images/contact.png" />
                </div>
               
                <div class="button-name">
                    <span> CONTACT<br/>U</span>S
                </div>
            </div>
           
            <hr class="divider-line"/>
           
            <div class="button-logo">
                <a class="button" href="#popup1">
                    <div>
                        <img src = "images/search.png" />
                    </div>
                   
                    <div class="button-name">
                         <span> SEARC</span>H
                    </div>
                </a>
               
                <div id="popup1" class="overlay">
                    <div class="popup">
                        <h2> Navigate through TaskEase </h2>
                        <a class="close" href="#">&times;</a>
                        <div class="content">
                            <input type="text" id="searchInput" placeholder="Enter the task title.">
                            <button onclick="search()">SEARCH</button>
                            <div id="searchResults"></div>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="button-logo" id="button-hover" onclick="redirectToProfile();">
                <div>
                    <img src = "images/profile.png" />
                </div>
               
                <div class="button-name">
                    <span> PROFIL</span>E
                </div>
            </div>
           
            <div class="button-logo">
                <a class="button" href="#popup2">
                    <div>
                        <img src = "images/more.png" />
                    </div>
                   
                    <div class="button-name">
                         <span> MOR</span>E
                    </div>
                </a>
               
                <div id="popup2" class="overlay">
                    <div class="popup">
                        <h2> MORE SETTINGS </h2>
                        <a class="close" href="#">&times;</a>
                        <div class="content">
                            <button onclick="logout()">LOGOUT</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
               
        <div class="add-task">
            <a class="add-button" href="#popup3">
                <span class="add-sign"> + </span>          
            </a>
               
            <div id="popup3" class="overlay">
                <div class="popup">
                    <h2> CREATE A TASK </h2>
                    <hr/>
                    <a class="close" href="#">&times;</a>
                    <div class="add-content">
                        <form action="#" method="post">
                            <div class="field">
                                <input type="text" name="taskname" required>
                                <label>Task Name</label>
                            </div>
                           
                            <div class="field">
                                <input type="text" name="taskdate" required>
                                <label>Date of Completion</label>
                            </div>
                           
                            <div class="desc-field">
                                <input type="text" name="taskdescription" required>
                                <label>Task Description</label>
                            </div>
                           
                            <div class="field">
                                <input type="submit" value="CREATE" name="btnCreate">
                            </div>
                         </form>
                    </div>
                </div>
            </div>
        </div>
                   
        <div class="dashboard">
            <div class="dashboard-header">
                <div class="header-title-group">
                    <div class="header-title">
                        <span> WELCOME , USER !</span>
                        <!-- name sa user ari brix -->
                    </div>
                   
                    <div class="lower-header">
                        <div>
                            <hr/>
                        </div>
                        <span> LET'S START YOUR DAY CREATING A TASK </span>
                    </div>
                </div>
               
                <div id="datetime">
                    <span id="date"></span><br>
                    <span id="time"></span>
                </div>
            </div>
               
            <div class="body-section">
                <input type="radio" id="all-tab" name="sec-a" checked="checked">
                <label for="all-tab" class="section-all">
                    <div>
                        <img src="images/all.png">
                    </div>
                       
                    <div>
                        <span> All Tasks </span>
                    </div>
                </label>
                <div class="all-content">
                    <div class="section-header">
                        <h2> ALL TASKS </h2>
                        <h5> Sorted by: Newest to Oldest </h5>
                    </div>
                    <hr/>
                    <div class="no-alltasks">
                    <?php
                    $sql = "SELECT * FROM tbltask ORDER BY taskdate ASC";
                    $result = mysqli_query($connection, $sql);
 
                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                    ?>
                            <table class="task-table">
                                <tr class="task-format">
                                    <td class="task-name"><?php echo $row["taskname"]; ?></td>
                                    <td class="task-desc"><?php echo $row["taskdescription"]; ?></td>
                                    <td class="task-date"><?php echo $row["taskdate"]; ?></td>
                                    <td class="task-button">
                                        <a class="view-button" href="#popup4">
                                            <button class="func-button" onclick="viewTask('<?php echo $row["taskname"]; ?>')">View</button>
                                        </a>
 
                                        <div id="popup4" class="overlay">
                                            <div class="popup">
                                                <h2> VIEW A TASK </h2>
                                                <hr/>
                                                <a class="close" href="#">&times;</a>
                                                <div class="add-content">
                                                    <form action="#" method="post">
                                                        <input type="hidden" name="taskname" value="<?php echo $row["taskname"]; ?>">
                                                        <div class="field">
                                                            <input type="text" name="taskname" value="<?php echo $row["taskname"]; ?>" required>
                                                            <label>Task Name</label>
                                                        </div>
 
                                                        <div class="field">
                                                            <input type="text" name="taskdate" value="<?php echo $row["taskdate"]; ?>" required>
                                                            <label>Date of Completion</label>
                                                        </div>
 
                                                        <div class="desc-field">
                                                            <input type="text" name="taskdescription" value="<?php echo $row["taskdescription"]; ?>" required>
                                                            <label>Task Description</label>
                                                        </div>
 
                                                        <div class="field">
                                                            <input type="submit" value="UPDATE" name="btnUpdate">
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
 
                                        <button class="func-button" onclick="deleteTask('<?php echo $row["taskname"]; ?>')">Delete</button>
                                    </td>
                                <tr>
                            </table>
                    <?php
                        }
                    } else {
                    ?>
                        <div>
                            <img src="images/notasks.png">
                        </div>
                        <div>
                            <span> There are currently no newly created task/s as of the moment. </span>
                        </div>
                    <?php
                    }
                    ?>
                </div>
                </div>
 
                <div id="popup4" class="overlay">
                <div class="popup">
                    <h2> TASK DETAILS </h2>
                    <a class="close" href="#">&times;</a>
                    <div class="content">
                    <div id="taskDetails"></div>
                    </div>
                </div>
                </div>
                   
                <input type="radio" id="important-tab" name="sec-a">
                <label for="important-tab" class="section-important">
                    <div>
                        <img src="images/important.png">
                    </div>
                       
                    <div>
                        <span> Important Tasks </span>
                    </div>
                </label>
                <div class="all-content">
                    <div class="section-header">
                        <h2> IMPORTANT TASKS </h2>
                        <h5> Sorted by: Newest to Oldest </h5>
                    </div>
                    <hr/>
                    <div class="no-alltasks">
                        <div>
                            <img src="images/nofav.png">
                        </div>
                        <div>
                            <span> There are currently no newly important<br/>task/s as of the moment. </span>
                        </div>
                       
                        <!-- ari dapat mabutang ang mga newly created na tasks brix-->
                    </div>
                </div>
                   
                <input type="radio" id="deleted-tab" name="sec-a">
                <label for="deleted-tab" class="section-deleted">
                    <div>
                        <img src="images/deleted.png">
                    </div>
                       
                    <div>
                        <span> Recently Deleted </span>
                    </div>
                </label>
                <div class="all-content">
                    <div class="section-header">
                        <h2> RECENTLY DELETED </h2>
                        <h5> Sorted by: Newest to Oldest </h5>
                    </div>
                    <hr/>
                    <div class="no-alltasks">
                        <div>
                            <img src="images/recycle.png">
                        </div>
                        <div>
                            <span> There are currently no newly deleted<br/>task/s as of the moment. </span>
                        </div>
                       
                        <!-- ari dapat mabutang ang mga newly created na tasks brix-->
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
 
<?php
if (isset($_POST['btnCreate'])) {
    $taskname = mysqli_real_escape_string($connection, $_POST['taskname']);
    $taskdescription = mysqli_real_escape_string($connection, $_POST['taskdescription']);
    $taskdate = mysqli_real_escape_string($connection, $_POST['taskdate']);
 
    $checkSql = "SELECT * FROM tblTask WHERE taskname = '$taskname'";
    $checkResult = mysqli_query($connection, $checkSql);
    $checkRow = mysqli_fetch_assoc($checkResult);
 
    if (mysqli_num_rows($checkResult) > 0) {
        echo "<script>alert('Task name already exists. Please choose a different name.');</script>";
    } else {
        $sql = "Insert into tblTask(taskname, taskdescription, taskdate) values('$taskname', '$taskdescription', '$taskdate')";
        mysqli_query($connection, $sql);
    }
}
?>
 
 
<?php
if (isset($_POST['btnUpdate'])) {
    $taskname = $_POST['taskname'];
    $taskdate = $_POST['taskdate'];
    $taskdescription = $_POST['taskdescription'];
 
    $sql = "UPDATE tbltask SET taskdate='$taskdate', taskdescription='$taskdescription' WHERE taskname='$taskname'";
    $result = mysqli_query($connection, $sql);
 
    if ($result) {
        echo "Task updated successfully!";
    } else {
        echo "Error updating task: " . mysqli_error($connection);
    }
}
?>