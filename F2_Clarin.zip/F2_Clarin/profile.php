<?php
    include 'connect.php';

    $sql = "SELECT * FROM tblTask";
    $result = mysqli_query($connection, $sql);
    $tableRows = "";

    while ($row = mysqli_fetch_assoc($result)) {
        $tableRows.= "<tr>";
        $tableRows.= "<td>". $row['taskID']. "</td>";
        $tableRows.= "<td>". $row['taskname']. "</td>";
        $tableRows.= "<td>". $row['taskdescription']. "</td>";
        $tableRows.= "<td>". $row['duedate']. "</td>";
        $tableRows.= "<td><button name='btnDelete' value='". $row['taskID']. "'>Delete</button></td>";
        $tableRows.= "</tr>";
    }

    if (isset($_POST['btnCreate'])) {
        $taskname = mysqli_real_escape_string($connection, $_POST['taskname']);
        $taskdescription = mysqli_real_escape_string($connection, $_POST['taskdescription']);
        $duedate = mysqli_real_escape_string($connection, $_POST['duedate']);

        $checkSql = "SELECT * FROM tblTask WHERE taskname = '$taskname'";
        $checkResult = mysqli_query($connection, $checkSql);
        $checkRow = mysqli_fetch_assoc($checkResult);

        if (mysqli_num_rows($checkResult) > 0) {
            echo "<script>alert('Task name already exists. Please choose a different name.');</script>";
        } else {
            $sql = "Insert into tblTask(taskname, taskdescription, duedate) values('$taskname', '$taskdescription', '$duedate')";
            mysqli_query($connection, $sql);
        }
    }

    if (isset($_POST['btnDelete'])) {
        $taskid = mysqli_real_escape_string($connection, $_POST['btnDelete']);

        $sql = "DELETE FROM tblTask WHERE taskID = '$taskID'";
        mysqli_query($connection, $sql);
    }
?>

    <html>
        <head>
            <title> TaskEase - About Us</title>
            <link rel="stylesheet" href="css/profileCSS.css">
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap">
            <script src="js/redirect-pages.js"></script>
            <meta name = "viewport" content = "width=device-width, initial-scale=1.0">
        </head>

        <body>
            <div class="page-header">
                <div class="header-logo">
                    <img src = "images/taskeaseLogo2.png" />
                </div>

                <div class="header-logo-name">
                    <div class="name-upper-text">
                        <span> TaskEase </span>
                    </div>

                    <div class="name-lower-text">
                        <span> task management</span>
                    </div>
                </div>

                <div class="header-anchors" onclick="redirectToIndex();">
                    <span> HOME </span>
                </div>

                <div class="header-anchors" onclick="redirectToAboutus();">
                    <span> ABOUT US </span>
                </div>

                <div class="header-anchors" onclick="redirectToContactus();">
                    <span> CONTACT US </span>
                </div>

                <div class="header-anchors" onclick="">
                    <span> PROFILE </span>
                </div>
            </div>

            <div class="addtaskright">
                <div>
                    <div class="headertask">
                        <div class="headername">
                            <span> TASK MANAGEMENT </span>
                        </div>

                        <div class="rowfunc">
                            <div class="functions">
                                <div class="searchbox">
									<input> </input>
                                </div>

                               <div class="btnsearch">
                                    <button> SEARCH </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class = "aboutus-body">
                        <div class="content-text">
                            <table class="createTable">
                                <tr>
                                    <td class="tableheader"> Number of Task</td>
                                    <td class="tableheader"> Task Name </td>
                                    <td class="tableheader"> Task Description </td>
                                    <td class="tableheader"> Due Date </td>
                                    <td class="tableheader"> Action </td>
                                </tr>
                                <?php echo $tableRows; ?>
                            </table>
                        </div>
                    </div>
                </div>
				
                <form action="#" method="post">
                    <div class="addingtask">
                        <div class="headername">
                            <span> TASK CREATOR<span>
                        </div>

                        <div>
                            <span> Task Name: </span> <br/>
                            <input type="text" name = "taskname" class="boxinfo">
                        </div>

                        <div>
                            <br/> <span> Task Description: </span> <br/>
                            <input type="text" name = "taskdescription" class="boxinfo1">
                        </div>

                        <div>
                            <br/> <span> Date of Completion: </span> <br/>
                            <input type="text" name = "duedate" class="boxinfo">
                        </div>

                        <div class="addtask" onclick="redirectToProfile();">
                            <button name = "btnCreate"> ADD </button>
                        </div>
                    </div>
                </form>
            </div>
        </body>
    </html>