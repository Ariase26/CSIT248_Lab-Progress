package com.example.clarinmidtermexamproject;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button[][] btnList;
    char[][] box = new char[][]{
            {' ',' ',' '},
            {' ',' ',' '},
            {' ',' ',' '}
    };
    Button btn11, btn21, btn31, btn12, btn22, btn32, btn13, btn23, btn33;
    Button reset;

    TextView txtPlayer;
    LinearLayout playerBg;
    boolean player1 = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn11 = (Button) findViewById(R.id.btn11);
        btn12 = (Button) findViewById(R.id.btn12);
        btn13 = (Button) findViewById(R.id.btn13);

        btn21 = (Button) findViewById(R.id.btn21);
        btn22 = (Button) findViewById(R.id.btn22);
        btn23 = (Button) findViewById(R.id.btn23);

        btn31 = (Button) findViewById(R.id.btn31);
        btn32 = (Button) findViewById(R.id.btn32);
        btn33 = (Button) findViewById(R.id.btn33);

        txtPlayer = (TextView) findViewById(R.id.txtPlayerName);
        playerBg = (LinearLayout) findViewById(R.id.lytBackground);
        reset = (Button) findViewById(R.id.btnReset);

        btnList = new Button[][]{
                {btn11, btn21, btn31},
                {btn12, btn22, btn32},
                {btn13, btn23, btn33}
        };

        for( int i = 0; i < 3; i++){
            for( int j = 0; j < 3; j++){
                int row = i, col = j;
                btnList[row][col].setOnClickListener(new View.OnClickListener() {
                    final int r = row;
                    final int c = col;

                    @Override
                    public void onClick(View v) {
                        if (box[r][c] == ' ') {
                            if(player1) {
                                box[r][c] = 'O';
                            } else {
                                box[r][c] = 'X';
                            }
                            player1 = !player1;
                            char turn = box[row][col];
                            btnList[row][col].setText(" " + turn);

                            updatePlayer();
                            //checkWinner();
                        }

                    }
                });
            }
        }

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gameReset();
            }
        });
    }

    public void updatePlayer(){
        if(player1) {
            playerBg.setBackgroundColor(Color.BLUE);
            txtPlayer.setText("Player O's Turn");
        } else {
            playerBg.setBackgroundColor(Color.RED);
            txtPlayer.setText("Player X's Turn");
        }
    }

    public void gameReset() {
        for( int i = 0; i < 3; i++){
            for( int j = 0; j < 3; j++){
                int row = i, col = j;
                btnList[row][col].setText(" ");
                playerBg.setBackgroundColor(Color.BLUE);
                txtPlayer.setText("Player O's Turn");
            }
        }
    }

//    public void checkWinner() {
//        if(     ( btnList[1][1].getText().equals('0') && btnList[1][2].getText().equals('0') && btnList[1][3].getText().equals('0') ) ||
//                ( btnList[2][1].getText().equals('0') && btnList[2][2].getText().equals('0') && btnList[1][3].getText().equals('0') ) ||    ) {
//
//        }
//
//        if()
//    }
}